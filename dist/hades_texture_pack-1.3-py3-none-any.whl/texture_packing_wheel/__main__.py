"""__main__: executed when texture packer directory is called as a script."""

from .texture_packing_wheel import main
main()